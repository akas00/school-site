<?php include("header.php"); ?>

<!-- Banner Section -->
	<section class="banner-section banner-height" style="background-image: url('images/event-banner.jpg');">

		<div class="banner-overlay"></div>
		<div class="container">
			<div class="banner-slogan">
				<h1 class="slogan">Facilities</h1>
			</div>
		</div>
	</section>



	<section class="events ">
	<div class="container">
		
			<div class="headings">
				<div class="left-heading">
					<h2>Facilities</h2>
				</div>
				<div class="right-heading">
					<h2>Services</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6">
					<div class="events-image">
						<a href="single-events.php">
						<img src="images/recent1.jpg">
						<div class="events-overlay "></div>
						</a>
					</div>
					<div class="events-details">
						<div class="shapes">
						<div class="rectangle">
						<p>Feb</p>
					</div>

					<div class="shape">
						<p>20</p>
					</div>
					</div>

					<div class="details">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing</p>
					</div>
					</div>

					
					

				</div>
				<div class="col-lg-4 col-md-6">
					
					<div class="events-image ">
						<a href="single-events.php">
						<img src="images/recent1.jpg ">
                         <div class="events-overlay "></div>
                         </a>
					</div>


					<div class="events-details">
						<div class="shapes">
						<div class="rectangle">
						<p>Feb</p>
					</div>

					<div class="shape">
						<p>20</p>
					</div>
					</div>

					<div class="details">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing</p>
					</div>
					</div>
					
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="events-image">
						<a href="">
						<img src="images/recent1.jpg">
						<div class="events-overlay "></div>
						</a>
					</div>
					<div class="events-details">
						<div class="shapes">
						<div class="rectangle">
						<p>Feb</p>
					</div>

					<div class="shape">
						<p>20</p>
					</div>
					</div>

					<div class="details">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing</p>
					</div>
					</div>
					
				</div>
			</div>

			


		
	</div>
</section>








	<?php include("footer.php"); ?>